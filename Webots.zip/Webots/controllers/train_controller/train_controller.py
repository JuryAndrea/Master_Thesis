"""train controller."""

# NOTE: save_db function is commented out avoiding the creation of the pickle file every time webots is started 
# uncommented it to save the data when needed

from controller import Supervisor, Camera, RangeFinder, DistanceSensor
import random
import math
import time
import pickle
import numpy as np
from PIL import Image

TIME_STEP = 32
INTERVAL = 0.0001
SCENE_INTERVAL = 20


# List of all the objects in the scene
humans_list = ["HUMAN_1", "HUMAN_2", "HUMAN_3", "HUMAN_4", "HUMAN_5"]
obj_list = ["OBJ_1", "OBJ_2", "OBJ_3", "OBJ_4", "OBJ_5"]
obj_colors = ["OBJ_COLOR_1", "OBJ_COLOR_2", "OBJ_COLOR_3", "OBJ_COLOR_4", "OBJ_COLOR_5"]
desk_list = ["DESK_1", "DESK_2", "DESK_3", "DESK_4", "DESK_5"]
oil_list = ["OIL_1", "OIL_2", "OIL_3", "OIL_4", "OIL_5"]
light_list = ["LIGHT_1", "LIGHT_2", "LIGHT_3", "LIGHT_4"]
fridge_list = ["FRIDGE_1", "FRIDGE_2", "FRIDGE_3", "FRIDGE_4", "FRIDGE_5"]
box_list = ["BOX_1", "BOX_2", "BOX_3", "BOX_4", "BOX_5"]
arm_list = ["ARM_1", "ARM_2", "ARM_3", "ARM_4", "ARM_5"]
chair_list = ["CHAIR_1", "CHAIR_2", "CHAIR_3", "CHAIR_4", "CHAIR_5"]
panel_list = ["PANEL_1", "PANEL_2", "PANEL_3", "PANEL_4", "PANEL_5"]
original_walls_list = [
    "WALL_1",
    "WALL_2",
    "WALL_3",
    "WALL_4",
    "WALL_5",
    "WIND_WALL_1",
    "WIND_WALL_2",
    "WIND_WALL_4",
    "WIND_WALL_3",
    "WIND_WALL_5",
    "ROOF",
]


# randomize the objects in the scene
def randomize_objs(objs, objs_colors):
    for obj, obj_color in zip(objs, objs_colors):

        size = [
            random.uniform(0.0, 2.0),
            random.uniform(0.0, 5.0),
            random.uniform(0.0, 2.5),
        ]
        obj.getField("size").setSFVec3f(size)

        color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        obj_color.getField("colorOverride").setSFColor(color)

        position = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]
        obj.getField("translation").setSFVec3f(position)
        obj.getField("rotation").setSFRotation(rotation)

# randomize the humans in the scene
def randomize_humans(humans):
    for human in humans:
        shirt_color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        pants_color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        shoes_color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        skin_color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        human.getField("shirtColor").setSFColor(shirt_color)
        human.getField("pantsColor").setSFColor(pants_color)
        human.getField("shoesColor").setSFColor(shoes_color)
        human.getField("skinColor").setSFColor(skin_color)

        position = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 1.27]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]
        human.getField("translation").setSFVec3f(position)
        human.getField("rotation").setSFRotation(rotation)

# randomize the desks in the scene
def randomize_desks(desks):
    for desk in desks:
        colors = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        desk.getField("color").setSFColor(colors)
        position = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]
        desk.getField("translation").setSFVec3f(position)
        desk.getField("rotation").setSFRotation(rotation)

# randomize the oil cans in the scene
def randomize_oils(oils):
    for oil in oils:

        height = random.uniform(0.0, 2.0)
        oil.getField("height").setSFFloat(height)

        radius = random.uniform(0.0, 1.0)
        oil.getField("radius").setSFFloat(radius)

        position = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]
        oil.getField("translation").setSFVec3f(position)
        oil.getField("rotation").setSFRotation(rotation)

# randomize the lights in the scene
def randomize_lights(lights):
    for light in lights:

        translation = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 2.0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]

        point_color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]

        intensity = random.uniform(0.0, 10.0)

        light.getField("pointLightColor").setSFColor(point_color)

        light.getField("pointLightIntensity").setSFFloat(intensity)

        light.getField("translation").setSFVec3f(translation)
        light.getField("rotation").setSFRotation(rotation)

# randomize the fridges in the scene
def randomize_frindges(fridges):
    for fridge in fridges:
        translation = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]

        color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        fridge.getField("mainColor").setSFColor(color)

        fridge.getField("translation").setSFVec3f(translation)
        fridge.getField("rotation").setSFRotation(rotation)

# randomize the boxes in the scene
def randomize_boxes(boxes):
    for box in boxes:
        translation = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]

        size = [
            random.uniform(0.01, 3),
            random.uniform(0.01, 3),
            random.uniform(0.01, 3),
        ]

        box.getField("size").setSFVec3f(size)
        box.getField("translation").setSFVec3f(translation)
        box.getField("rotation").setSFRotation(rotation)

# randomize the arm chairs in the scene
def randomize_arm_chairs(arm_chairs):
    for arm in arm_chairs:
        translation = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]

        color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]

        arm.getField("color").setSFColor(color)
        arm.getField("translation").setSFVec3f(translation)
        arm.getField("rotation").setSFRotation(rotation)

# randomize the chairs in the scene
def randomize_chairs(chairs):
    for chair in chairs:
        translation = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]

        leg_color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]

        seat_color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]

        chair.getField("legColor").setSFColor(leg_color)
        chair.getField("seatColor").setSFColor(seat_color)
        chair.getField("translation").setSFVec3f(translation)
        chair.getField("rotation").setSFRotation(rotation)

# randomize the panels in the scene
def randomize_panels(panels):
    for panel in panels:
        translation = [random.uniform(-6.0, 6.0), random.uniform(-3.0, 3.0), 0]
        rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]

        size = [
            random.uniform(0.01, 3),
            random.uniform(0.01, 3),
            random.uniform(0.01, 3),
        ]

        panel.getField("size").setSFVec3f(size)
        panel.getField("translation").setSFVec3f(translation)
        panel.getField("rotation").setSFRotation(rotation)

# randomize the floor texture in the scene
def randomize_floor(floor):
    list_ = ["chequered", "dark strip", "light strip", "mosaic"]
    choice = random.randint(0, len(list_) - 1)
    floor.getField("type").setSFString(list_[choice])

# randomize the background texture of the scene
def randomize_texture(texture):
    textures = [
        "dusk",
        "empty_office",
        "entrance_hall",
        "factory",
        "mars",
        "noon_building_overcast",
        "noon_cloudy_countryside",
        "noon_park_empty",
        "mountains",
        "music_hall",
        "stadium",
        "stadium_dry",
    ]
    choice = random.randint(0, len(textures) - 1)
    texture.getField("texture").setSFString(textures[choice])

# randomize the lightback in the scene
def randomize_lightback(lightback):
    environments = [
        "dawn_cloudy_empty",
        "dusk",
        "empty_office",
        "entrance_hall",
        "factory",
        "mars",
        "morning_cloudy_empty",
        "mountains",
        "music_hall",
        "noon_building_overcast",
        "noon_cloudy_countryside",
        "noon_cloudy_empty",
        "noon_cloudy_mountains",
        "noon_park_empty",
        "noon_stormy_empty",
        "noon_sunny_empty",
        "noon_sunny_garden",
        "stadium",
        "stadium_dry",
        "twilight_cloudy_empty",
    ]
    choice = random.randint(0, len(environments) - 1)
    lightback.getField("texture").setSFString(environments[choice])

# randomize the walls in the scene
def randomize_original_walls(original_walls):
    for wall in original_walls:
        color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        wall.getField("colorOverride").setSFColor(color)

# spawn the nano drone in a new position until the pose is not valid
def randomize_crazy(crazy):
    # get the translation and rotation fields
    crazy_translation_field = crazy.getField("translation")
    crazy_rotation_field = crazy.getField("rotation")

    # randomize the position
    new_position = [
        random.uniform(-5.5, 5.5),
        random.uniform(-2.5, 2.5),
        random.uniform(1.0, 2.4),
    ]
    crazy_translation_field.setSFVec3f(new_position)

    # get the contact points
    contactPoints = crazy.getContactPoints()

    # while the robot is unfeasible position, keep randomizing
    while len(contactPoints) > 0:
        new_position = [
            random.uniform(-5.5, 5.5),
            random.uniform(-2.5, 2.5),
            random.uniform(1.0, 2.4),
        ]
        crazy_translation_field.setSFVec3f(new_position)
        contactPoints = crazy.getContactPoints()

    # randomize the rotation
    new_rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]
    crazy_rotation_field.setSFRotation(new_rotation)

    return new_position, new_rotation

# save the data in a pickle file
def save_db(id, pos, rot, dist, img, dth):

    db = (id, pos, rot, dist, img, dth)

    dbfile = open(
        "data/db.pkl",
        "ab",
    )
    pickle.dump(db, dbfile)
    dbfile.close()


def run():

    # Create the supervisor instance and get the robot node
    supervisor = Supervisor()
    crazy = supervisor.getFromDef("Crazy")
    root_node = supervisor.getRoot()  

    # get all the objects in the scene
    humans = [supervisor.getFromDef(human) for human in humans_list]
    objs = [supervisor.getFromDef(obj) for obj in obj_list]
    objs_colors = [supervisor.getFromDef(obj_color) for obj_color in obj_colors]
    desks = [supervisor.getFromDef(desk) for desk in desk_list]
    oils = [supervisor.getFromDef(oil) for oil in oil_list]
    lights = [supervisor.getFromDef(light) for light in light_list]
    fridges = [supervisor.getFromDef(fridge) for fridge in fridge_list]
    original_walls = [supervisor.getFromDef(wall) for wall in original_walls_list]
    
    floor = supervisor.getFromDef("REC")
    texture = supervisor.getFromDef("TEXTURE")
    light_back = supervisor.getFromDef("LIGHTBACK")

    # Enable camera, range finder and distance sensor
    camera = supervisor.getDevice("camera")
    camera.enable(TIME_STEP)

    range_finder = RangeFinder("range-finder")
    range_finder.enable(TIME_STEP)

    front_range = DistanceSensor("range_front")
    front_range.enable(TIME_STEP)

    # image id
    id = 1

    last_time_nanodrone = 0

    # Main loop
    while supervisor.step(TIME_STEP) != -1:

        current_time = supervisor.getTime()

        # Emit new particle at regular intervals
        if current_time - last_time_nanodrone >= INTERVAL:

            # set a new position and rotation
            new_position, new_rotation = randomize_crazy(crazy)

            front_distance = front_range.getValue()

            # Get what the camera sees
            camera_img = f"images/camera_{id}.png"
            camera.saveImage(camera_img, 100)
            img = Image.open(camera_img)
            img = np.array(img)

            depth_img = f"depth_images/depth_{id}.png"
            range_finder.saveImage(depth_img, 100)
            dth = Image.open(depth_img)
            dth = np.array(dth)

            # Save data
            # save_db(id, new_position, new_rotation, front_distance, img, dth)

            id += 1

            last_time_nanodrone = current_time

            # Randomize the scene every 20 images
            if id % 20 == 0:

                randomize_original_walls(original_walls)

                random_seeds = [random.randint(0, 2**32 - 1) for _ in range(6)]

                random.seed(random_seeds[0])
                num_humans = random.randint(0, len(humans))
                randomize_humans(humans[:num_humans])

                random.seed(random_seeds[1])
                num_objs = random.randint(0, len(objs))
                randomize_objs(objs[:num_objs], objs_colors[:num_objs])

                random.seed(random_seeds[2])
                num_desks = random.randint(0, len(desks))
                randomize_desks(desks[:num_desks])

                random.seed(random_seeds[3])
                num_oils = random.randint(0, len(oils))
                randomize_oils(oils[:num_oils])

                random.seed(random_seeds[4])
                num_lights = random.randint(0, len(lights))
                randomize_lights(lights[:num_lights])

                random.seed(random_seeds[5])
                num_fridges = random.randint(0, len(fridges))
                randomize_frindges(fridges[:num_fridges])

                randomize_floor(floor)
                randomize_texture(texture)
                randomize_lightback(light_back)


if __name__ == "__main__":
    run()
