"""test controller."""

# NOTE: save_db function is commented out avoiding the creation of the pickle file every time webots is started 
# uncommented it to save the data when needed

from controller import Supervisor, Camera, RangeFinder, DistanceSensor
import random
import math
import time
import pickle
import numpy as np
from PIL import Image

TIME_STEP = 32
INTERVAL = 0.0001
SCENE_INTERVAL = 20

# List of all the objects in the scene
floors_list = ["FLOOR"]
walls_list = ["WALLS"]
roofs_color_list = ["ROOF_COLOR"]
lamps_list = ["LAMP_1", "LAMP_2", "LAMP_3", "LAMP_4", "LAMP_5", "LAMP_6", "LAMP_7", "LAMP_8", "LAMP_9"]
lights_list = ["LIGHT"]
humans_list = ["HUMAN_1", "HUMAN_2", "HUMAN_3", "HUMAN_4", "HUMAN_5", "HUMAN_6", "HUMAN_7"]
objs_list = ["OBJ_1", "OBJ_2", "OBJ_3", "OBJ_4", "OBJ_5", "OBJ_6", "OBJ_7", "OBJ_8", "OBJ_9", "OBJ_10", "OBJ_11", "OBJ_12"]
objs_col_list = ["OBJ_COL_1", "OBJ_COL_2", "OBJ_COL_3", "OBJ_COL_4", "OBJ_COL_5", "OBJ_COL_6", "OBJ_COL_7", "OBJ_COL_8", "OBJ_COL_9", "OBJ_COL_10", "OBJ_COL_11", "OBJ_COL_12"]


# spawn the nano drone in a new position until the pose is not valid
def randomize_crazy(crazy):
    crazy_translation_field = crazy.getField("translation")
    crazy_rotation_field = crazy.getField("rotation")

    # randomize the position
    new_position = [
        random.uniform(-6.5, 6.5),
        random.uniform(-6.5, 6.5),
        random.uniform(1.0, 3.0),
    ]
    crazy_translation_field.setSFVec3f(new_position)

    # get the contact points
    contactPoints = crazy.getContactPoints()

    # while the robot is unfeasible position, keep randomizing
    while len(contactPoints) > 0:
        new_position = [
            random.uniform(-6.5, 6.5),
            random.uniform(-6.5, 6.5),
            random.uniform(1.0, 3.0),
        ]
        crazy_translation_field.setSFVec3f(new_position)
        contactPoints = crazy.getContactPoints()

    # randomize the rotation
    new_rotation = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]
    crazy_rotation_field.setSFRotation(new_rotation)

    return new_position, new_rotation

# randomize the floor texture in the scene
def randomize_floors(floors):
    for floor in floors:
        
        list_ = ["oval", "square"]
        choice = random.randint(0, len(list_) - 1)
        
        floor.getField("type").setSFString(list_[choice])
        
        new_color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]
        floor.getField("colorOverride").setSFColor(new_color)

# randomize the wall color in the scene
def randomize_walls(walls):
    for wall in walls:
        seed = random.randint(0, 2**32 - 1)
        random.seed(seed)
        np.random.seed(seed)
        new_color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]
        wall.getField("colorOverride").setSFColor(new_color)

def randomize_roofs(roofs_color):
    for roof_color in roofs_color:
        new_color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]
        roof_color.getField("colorOverride").setSFColor(new_color)

# randomize the lamp position, rotation and intensity
def randomize_lamps(lamps):
    for lamp in lamps:
        seed = random.randint(0, 2**32 - 1)
        random.seed(seed)
        np.random.seed(seed)
        
        new_pos = [random.uniform(-6.5, 6.5), random.uniform(-6.5, 6.5), random.uniform(1.0, 3.0)]
        lamp.getField("translation").setSFVec3f(new_pos)
        
        new_rot = [0.0, 0.0, 1.0, random.uniform(-math.pi/2, math.pi/2)]
        lamp.getField("rotation").setSFRotation(new_rot)
        
        intensity = random.uniform(0, 100)
        lamp.getField("intensity").setSFFloat(intensity)

# randomize the light position, rotation, color and intensity
def randomize_lights(lights):
    for light in lights:
        
        seed = random.randint(0, 2**32 - 1)
        random.seed(seed)
        np.random.seed(seed)
        
        new_pos = [random.uniform(-6.5, 6.5), random.uniform(-6.5, 6.5), random.uniform(1.0, 3.0)]
        light.getField("translation").setSFVec3f(new_pos)
        
        new_rot = [0.0, 0.0, 1.0, random.uniform(-math.pi/2, math.pi/2)]
        light.getField("rotation").setSFRotation(new_rot)
        
        support_color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]
        light.getField("supportColor").setSFColor(support_color)
        
        light_int = random.uniform(0, 100)
        light.getField("pointLightIntensity").setSFFloat(light_int)
        
        light_color = [random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)]
        light.getField("pointLightColor").setSFColor(light_color)

# randomize the human position, rotation and color of the clothes
def randomize_humans(humans):
    for human in humans:
        
        seed = random.randint(0, 2**32 - 1)
        random.seed(seed)
        np.random.seed(seed)
        
        new_pos = [random.uniform(-6.5, 6.5), random.uniform(-6.5, 6.5), 1.27]
        human.getField("translation").setSFVec3f(new_pos)
        
        new_rot = [0.0, 0.0, 1.0, random.uniform(0 , 2 * math.pi)]
        human.getField("rotation").setSFRotation(new_rot)
        
        colors = [[random.uniform(0, 1), random.uniform(0, 1), random.uniform(0, 1)] for _ in range(4)]
        
        human.getField("shirtColor").setSFColor(colors[0])
        human.getField("pantsColor").setSFColor(colors[1])
        human.getField("shoesColor").setSFColor(colors[2])
        human.getField("skinColor").setSFColor(colors[3])

# randomize the object position, rotation, size and color
def randomize_objs(objs, objs_colors):
    for obj, obj_color in zip(objs, objs_colors):
        
        seed = random.randint(0, 2**32 - 1)
        random.seed(seed)
        np.random.seed(seed)
        
        
        new_pos = [random.uniform(-6.5, 6.5), random.uniform(-6.5, 6.5), random.uniform(1.0, 2.5)]
        new_rot = [0.0, 0.0, 1.0, random.uniform(0.0, 2 * math.pi)]
        
        obj.getField("translation").setSFVec3f(new_pos)
        obj.getField("rotation").setSFRotation(new_rot)
        
        size = [
            random.uniform(2.0, 5.0),
            random.uniform(2.0, 5.0),
            random.uniform(0.75, 2.5),
        ]
        obj.getField("size").setSFVec3f(size)
        
        color = [
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        ]
        obj_color.getField("colorOverride").setSFColor(color)

# save the data in a pickle file
def save_db(id, pos, rot, dist, img, dth):
    db = (id, pos, rot, dist, img, dth)

    dbfile = open(
        "data/df_test_new_room.pkl",
        "ab",
    )
    pickle.dump(db, dbfile)
    dbfile.close()


def run():
    
    # Create the Supervisor and get the root node of the scene tree
    supervisor = Supervisor() 
    crazy = supervisor.getFromDef("Crazy")
    root_node = supervisor.getRoot()
    
    # get the objects from the scene
    floors = [supervisor.getFromDef(floor) for floor in floors_list]
    walls = [supervisor.getFromDef(wall) for wall in walls_list]
    roofs_color = [supervisor.getFromDef(roof_color) for roof_color in roofs_color_list]
    lamps = [supervisor.getFromDef(lamp) for lamp in lamps_list]
    lights = [supervisor.getFromDef(light) for light in lights_list]
    humans = [supervisor.getFromDef(human) for human in humans_list]
    objs = [supervisor.getFromDef(obj) for obj in objs_list]
    objs_col = [supervisor.getFromDef(obj_col) for obj_col in objs_col_list]
    
    # activate the camera, range finder and distance sensor
    camera = supervisor.getDevice("camera")
    camera.enable(TIME_STEP)

    range_finder = RangeFinder("range-finder")
    range_finder.enable(TIME_STEP)

    front_range = DistanceSensor("range_front")
    front_range.enable(TIME_STEP)

    # image id
    id = 1
    
    
    last_time_nanodrone = 0
    
    # Main loop
    while supervisor.step(TIME_STEP) != -1:
        current_time = supervisor.getTime()
        if current_time - last_time_nanodrone >= INTERVAL:
            new_position, new_rotation = randomize_crazy(crazy)

            front_distance = front_range.getValue()

            # Get what the camera sees
            camera_img = f"test_images/camera_{id}.png"
            camera.saveImage(camera_img, 100)
            img = Image.open(camera_img)
            np_img = np.array(img)

            depth_img = f"test_depth_images/depth_{id}.png"
            range_finder.saveImage(depth_img, 100)
            dth = Image.open(depth_img)
            dth_img = np.array(dth)

            # Save data
            # save_db(id, new_position, new_rotation, front_distance, np_img, dth_img)

            id += 1

            last_time_nanodrone = current_time
            
            # randomize the scene every 20 images
            if id % 20 == 0:
                
                random_seeds = [random.randint(0, 2**32 - 1) for _ in range(7)]

                random.seed(random_seeds[0])
                np.random.seed(random_seeds[0])
                randomize_floors(floors)
                
                random.seed(random_seeds[1])
                np.random.seed(random_seeds[1])
                randomize_walls(walls)
                
                random.seed(random_seeds[2])
                np.random.seed(random_seeds[2])
                randomize_roofs(roofs_color)
                
                random.seed(random_seeds[3])
                np.random.seed(random_seeds[3])
                randomize_lamps(lamps)
                
                random.seed(random_seeds[4])
                np.random.seed(random_seeds[4])
                randomize_lights(lights)
                
                random.seed(random_seeds[5])
                np.random.seed(random_seeds[5])
                randomize_humans(humans)
                
                random.seed(random_seeds[6])
                np.random.seed(random_seeds[6])
                randomize_objs(objs, objs_col)

if __name__ == "__main__":
    run()